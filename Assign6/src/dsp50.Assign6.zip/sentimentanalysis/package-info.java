/** This package contains classes and methods for sentiment analysis
    CS 3354 Fall 2018, Texas State University.
    @author vangelis
    @author jelena
    @author junye
*/
package sentimentanalysis;
