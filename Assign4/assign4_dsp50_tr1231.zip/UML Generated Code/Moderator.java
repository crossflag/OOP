
import java.util.*;

/**
 * 
 */
public class Moderator extends Member {

    /**
     * Default constructor
     */
    public Moderator() {
    }

    /**
     * 
     */
    public void permission2;

    /**
     * 
     */
    public void threadsHistory;


}