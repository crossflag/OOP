
import java.util.*;

/**
 * 
 */
public class Post {

    /**
     * Default constructor
     */
    public Post() {
    }



}