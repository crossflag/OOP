
import java.util.*;

/**
 * 
 */
public class AppManager {

    /**
     * Default constructor
     */
    public AppManager() {
    }

    /**
     * 
     */
    public void managePost;

    /**
     * 
     */
    public void manageThread;

    /**
     * 
     */
    public void manageForum;

    /**
     * 
     */
    public void notify;




}