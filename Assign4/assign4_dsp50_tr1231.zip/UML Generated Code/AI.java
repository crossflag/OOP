
import java.util.*;

/**
 * 
 */
public class AI {

    /**
     * Default constructor
     */
    public AI() {
    }

    /**
     * 
     */
    public void classify;

    /**
     * 
     */
    public void detectOffensive;

    /**
     * 
     */
    public void detectToxic;




}