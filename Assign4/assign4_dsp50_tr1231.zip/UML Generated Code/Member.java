
import java.util.*;

/**
 * 
 */
public class Member extends User {

    /**
     * Default constructor
     */
    public Member() {
    }

    /**
     * 
     */
    public void postHistory;

    /**
     * 
     */
    public void permission1;

}