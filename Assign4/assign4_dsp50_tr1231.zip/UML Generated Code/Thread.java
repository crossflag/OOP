
import java.util.*;

/**
 * 
 */
public class Thread {

    /**
     * Default constructor
     */
    public Thread() {
    }


}