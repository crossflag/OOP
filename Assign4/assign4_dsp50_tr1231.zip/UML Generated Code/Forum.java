
import java.util.*;

/**
 * 
 */
public class Forum {

    /**
     * Default constructor
     */
    public Forum() {
    }

}