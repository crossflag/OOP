
import java.util.*;

/**
 * 
 */
public class userDB {

    /**
     * Default constructor
     */
    public userDB() {
    }

    /**
     * 
     */
    public void login;

    /**
     * 
     */
    public void editInfo;

    /**
     * 
     */
    public void createAccount;

    /**
     * 
     */
    public void manageUser;

    /**
     * 
     */
    public void banUser;



}