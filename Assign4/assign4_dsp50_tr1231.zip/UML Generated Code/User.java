
import java.util.*;

/**
 * 
 */
public class User extends User {

    /**
     * Default constructor
     */
    public User() {
    }

    /**
     * 
     */
    public void name;

    /**
     * 
     */
    public void info;

    /**
     * 
     */
    public void password;


}