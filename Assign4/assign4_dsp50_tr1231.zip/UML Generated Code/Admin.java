
import java.util.*;

/**
 * 
 */
public class Admin extends Moderator {

    /**
     * Default constructor
     */
    public Admin() {
    }

    /**
     * 
     */
    public void permision3;

    /**
     * 
     */
    public void forumHistory;


}